import string
import random
from . import Constants
import boto3
import yaml
import os


class Genericfunc:
    
    @staticmethod
    def generate_unique_string():
        characters = string.ascii_letters + string.digits  # Include letters and digits
        return ''.join(random.choice(characters) for _ in range(Constants.KET_LENGTH))
    
    @staticmethod
    def read_data_from_yml(key):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(script_dir, "../config.yaml")
        # Read data from YAML file using read_text() and yaml.safe_load()
        with open(file_path, 'r') as file:
            data = yaml.safe_load(file.read())

        # Access the data
        val = data.get(key)
        return val
        
    @staticmethod
    def upload_file_s3(file, device_id, time_stamp):
        """
        upload file on s3
        Args:
            file (file): stream for file

        Returns:
            float: file size
        """
        s3 = boto3.client('s3', aws_access_key_id=Genericfunc.read_data_from_yml('AWS_ACCESS_KEY'),
                    aws_secret_access_key=Genericfunc.read_data_from_yml('AWS_SECRET_KEY'))
        bucket_name = Genericfunc.read_data_from_yml('AWS_BUCKET_NAME')
        s3_key = 's3/' + str(time_stamp) + '/' + str(device_id) + '/'
        s3.upload_fileobj(
            file,
            bucket_name,
            s3_key + file.filename
            # ExtraArgs={"ACL": "public-read"},
        )
        res_file_info = s3.head_object(Bucket = bucket_name, Key = s3_key + file.filename)
        file_size = res_file_info['ContentLength']
        return file_size, True
    
    @staticmethod
    def download_file_s3():
        """
        download file from s3
        Args:
            file_name (s3 object name): name of file to be accessed  

        Returns:
            file_data: return file data
        """
        s3 = boto3.client('s3', aws_access_key_id=Genericfunc.read_data_from_yml('AWS_ACCESS_KEY'),
                    aws_secret_access_key=Genericfunc.read_data_from_yml('AWS_SECRET_KEY'))
        bucket_name = Genericfunc.read_data_from_yml('AWS_BUCKET_NAME')
        file_name = 'route.py'
        
        response = s3.get_object(Bucket=bucket_name,Key = file_name)
        
        
        return response