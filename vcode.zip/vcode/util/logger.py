import logging
import os
from logging.handlers import RotatingFileHandler
from .Genericfunc import Genericfunc



class Logger(object):
    @staticmethod
    def get_logger():
        """
            This method returns a logger object and configures logging as per
            Parameters defined in configuration file
        Return:
            logger: It returns logger object.
        """
        logger = None
        try:
            logger = logging.getLogger(__name__)
            if not logger.handlers:
                LOGGER_FORMATTER = "[%(asctime)s] - %(levelname)s [%(filename)s:%(lineno)d] :\
            %(message)s"
            
                logger_level = Genericfunc.read_data_from_yml('LOGGER_LEVEL')
                
                file_path = os.path.abspath(__file__)
                logging_file_path = os.path.dirname(file_path)
                logging_file_path = logging_file_path + '/as.log'
                max_bytes = Genericfunc.read_data_from_yml("MAX_BYTES")
                backup_count = Genericfunc.read_data_from_yml("BACKUP_COUNT")
                handler = RotatingFileHandler(logging_file_path, 'w', max_bytes, backup_count)
                handler.doRollover()
                formatter = logging.Formatter(LOGGER_FORMATTER)
                handler.setFormatter(formatter)
                logger.addHandler(handler)
                logger.setLevel(logger_level)
        except Exception as error:
            logger.error(error)
            #raise ASRConfigError
            raise Exception()
        return logger