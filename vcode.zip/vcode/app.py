from flask import Flask, jsonify, Blueprint
from MyApplication import MyApplication
import device, ui
from flask_cors import CORS

app = MyApplication.create_app()
CORS(app)

# app = Flask(__name__)

def initialize():
    app.register_blueprint(device.device_bp, url_prefix='/device')
    app.register_blueprint(ui.device_ui, url_prefix='/user')

if __name__ == '__main__':
   initialize()   
   app.run(host="0.0.0.0", port=5000)
