from flask import jsonify, request, Blueprint
from sqlalchemy.exc import IntegrityError
from botocore.exceptions import NoCredentialsError
from datetime import datetime, timedelta
from flask import Flask, request, redirect
from flask_jwt_extended import JWTManager, jwt_required, create_access_token, get_jwt_identity
from ui.Validation import Validation
from util.logger import Logger
from ui.model.DbUtil import DbUtil
from device.model.DeviceHeartBeat import DeviceHeartBeat
from device.model.DeviceRegistration import DeviceRegistration
from ui.model.DeviceUserRegister import DeviceUserRegister
from decimal import Decimal

logger = Logger.get_logger()
from MyApplication import MyApplication


device_ui = Blueprint('user', __name__)
Decimal
status_dict = {1:'Starting',2:'Onlne',3:'Error',4:'In-Active',5:'Offline'}
@device_ui.route('/')
def hello_world():
    return {'msg': 'Hello Device APP!'}



@device_ui.route('/user_registration', methods=['POST'])
def user_registration():
    try:
        data = request.get_json()
        if not data or 'username' not in data or 'password' not in data or 'email' not in data:
            return {'error_msg': 'invalid payload'}, 400
        username = data['username']
        password = data['password']
        email = data['email']
        password_hash = Validation.password_hashing(password)
        if Validation.is_valid_email(email) is False:
            return {'error_msg': 'invalid email'}, 400
        DbUtil.insert_data_into_device_user(username, password_hash, email)
    except IntegrityError as e:
        print(f"IntegrityError => {e}")
        return {'error_msg':'duplicate entry for user'},409
    except Exception as error_obj:
        print(f"error occured = {error_obj}")
        return {'error_msg': error_obj}, 500
    return {'msg':'user registered successfully'},201
    

@device_ui.route('/user_login', methods=['POST'])
@Validation.validate_user
def user_login(user_info):
    try:
        jwt = MyApplication.get_jwt()
        continue_time = datetime.utcnow()
        expiration_time = datetime.utcnow() + timedelta(hours=1)
        user_identity = {"user_id": user_info.user_id, 'exp':expiration_time}
        access_token = create_access_token(identity=user_identity)
        return jsonify(
            access_token=access_token,
            created_at=continue_time,  # Get the issued at time
            expires_at=expiration_time   # Get the expiration time
        ), 200
        print(f"IntegrityError => {e}")
        return {'error_msg':'duplicate entry for user'},409
    except Exception as error_obj:
        print(f"error occured = {error_obj}")
        return {'error_msg': error_obj}, 500

@device_ui.route('/devices', methods=['GET'])
@jwt_required()
def device_list():
    try:
        db = MyApplication.get_db()
        result = db.session.query(DeviceRegistration, DeviceHeartBeat).join(DeviceHeartBeat, DeviceRegistration.id == DeviceHeartBeat.device_id).all()
        data = []
        for deviceregistration, deviceheartBeat in result:
            latitude = deviceregistration.latitude
            longitude = deviceregistration.longitude
            if latitude is not None:
               latitude = latitude.__float__()
               longitude = longitude.__float__()
            row_dict = {'device_id':deviceheartBeat.device_id, 'status_code':deviceheartBeat.status,'time_stsmp':deviceheartBeat.last_beat_time, 'status': status_dict[deviceheartBeat.status],'latitude':latitude, 'longitude':longitude}
            data.append(row_dict)
    except Exception as error_obj:
        print(f"error occured = {error_obj}")
        return {'error_msg': error_obj}, 500
    return jsonify(data),200

@device_ui.route('/me', methods=['GET'])
@jwt_required()
def user_info():
    # Access the identity of the current user with get_jwt_identity
    try:
        info = get_jwt_identity()
        user = DeviceUserRegister.query.filter(DeviceUserRegister.user_id == info['user_id']).first()
        print(user)
        return jsonify(
            user_name = user.username,
            user_email = user.email
        ), 200
    except Exception as error_obj:
        print(f"error occured = {error_obj}")
        return {'error_msg': error_obj}, 500