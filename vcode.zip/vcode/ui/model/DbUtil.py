from sqlalchemy import create_engine, select, MetaData, Table, and_, insert
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine, select, MetaData, Table, and_, insert
from datetime import datetime
from ui.model.DeviceUserRegister import DeviceUserRegister
from MyApplication import MyApplication

db = MyApplication.get_db()
class DbUtil():
    """
    A class representing a simple car.

    Attributes:
    - db_user (str): database user.
    - db_password (str): database password.
    - db_host (int): database host.
    - db_name (str): database name.
    - db_url (str): database url for connection.

    Methods:
    - get_url(): return db url for connection.
    - insert_data_into_device_registration(api_key: str, secret_key: str, actual_id: int, device_details: str):
      insert api_key, secret_ket, id, device_detail in device table
    - insert_data_into_device_metadata(api_key, secret_key, file_name, file_size, upload_time):
      check if api_key and secret_key present in device table, insert all file information which upload in device_metadata table
    - insert_data_into_device_info(self, secret_key, api_key):
      check if api_key and secret_key present in device table, insert all file information which upload in device_heartbeat table
    - select_data_device_info(secret_key: str, api_Key: str):
      check api_key and secret_key present in device table.
    """
    
    @staticmethod
    def insert_data_into_device_user(username, password, email):
        """
        this method used by API heartbeat
        check if device is registered using secret_key and api_key, store time stamp with api and secret key in device_heartbeat
        table
        Args:
            secret_key (str): take from payload
            api_key (str): take from payload

        Returns:
            list: reponse msg+statuscode
        """
        try:
            new_record = DeviceUserRegister(username=username, password=password, email=email)
            db.session.add(new_record)
            db.session.commit()
        finally:
            db.session.close()
              
    