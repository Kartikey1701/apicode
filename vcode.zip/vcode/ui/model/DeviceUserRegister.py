from MyApplication import MyApplication
from marshmallow import fields
from sqlalchemy.dialects.postgresql import BIT

db = MyApplication.get_db()
ma = MyApplication.get_ma()

class DeviceUserRegister(db.Model):
    __tablename__ = 'device_user'  # Replace with your actual table name
    user_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String, primary_key=True)
    password = db.Column(db.String)
    email = db.Column(db.String)