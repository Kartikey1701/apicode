from functools import wraps
from flask import request
import bcrypt
import re
from ui.model.DeviceUserRegister import DeviceUserRegister

class Validation():
    
    @staticmethod
    def validate_user(func):
        @wraps(func)
        def decorator_function(*args, **kwargs):
            data = request.get_json()
            if not data or 'username' not in data or 'password' not in data:
                return {'error_msg': 'invalid payload'}, 400
            user_name = data['username']
            password = data['password']
            if user_name is None or password is None:
                return {'error_msg': 'user_name or password missing'}, 400
            result = DeviceUserRegister.query.filter(DeviceUserRegister.username == user_name).first()
            print(result)
            if(result is None):
                return {'error_msg':'user not register'},404
            if bcrypt.checkpw(password.encode('utf-8'), result.password.encode('utf-8')) is False:
                return {'error_msg':'password wrong'},404
            return func(result, *args, **kwargs)
        return decorator_function
    
    @staticmethod
    def validate_payload(key_list, known_keys_list):
        return True if key_list == known_keys_list else False

    @staticmethod
    def validate_data(data, known_keys_list):
        if data is None:
            return False
        if all(key in known_keys_list for key in data.keys()):
            return True
        else:
            return False

    @staticmethod
    def password_hashing(password):
        # Hash a password with a randomly-generated salt
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        return hashed_password

    @staticmethod
    def is_valid_email(email):
        # Define a regular expression pattern for a basic email format
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        
        # Use re.match() to check if the email matches the pattern
        match = re.match(pattern, email)
        
        # Return True if there is a match, otherwise, return False
        return match is not None