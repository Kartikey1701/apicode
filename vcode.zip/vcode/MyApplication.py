import yaml
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from flask_jwt_extended import JWTManager, jwt_required, create_access_token, get_jwt_identity
from util.Genericfunc import Genericfunc

class MyApplication(object):

    app = None
    db = None
    ma = None
    jwt = None
    
    @classmethod
    def get_db(cls):
        if cls.db is None:
            cls.db = SQLAlchemy()
        return cls.db

    @classmethod
    def get_ma(cls):
        if cls.ma is None:
            cls.ma = Marshmallow()
        return cls.ma

    @classmethod
    def get_jwt(cls):
        return cls.jwt
    
    @classmethod
    def create_app(cls):
        if cls.app is None:
            app = Flask(__name__)
            app.config.from_file('config.yaml', load=yaml.safe_load)
            app.config['JWT_SECRET_KEY'] = Genericfunc.read_data_from_yml('JWT_SECRET_KEY')
            cls.get_db().init_app(app)
            cls.get_ma().init_app(app)
            jwt = JWTManager(app)
            cls.app = app

        return cls.app

    @classmethod
    def get_app(cls):
        return cls.create_app()
