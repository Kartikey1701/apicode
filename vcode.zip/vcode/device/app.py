from flask import jsonify, request, Blueprint, send_file
from device.model.DbUtil import DbUtil
from sqlalchemy.exc import IntegrityError
from botocore.exceptions import NoCredentialsError
from datetime import datetime
from flask import Flask, request, redirect
from device.Validation import Validation
from util.logger import Logger
from util.Genericfunc import Genericfunc
from traceback import format_exc


#logger = Logger.get_logger()
device_bp = Blueprint('device', __name__)
@device_bp.route('/')
def hello_world():
    return {'msg': 'Hello Device APP!'}




@device_bp.route('/registration', methods=['POST'])
def device_registration():
    """
    register device.

    Endpoint: /device/registration
    Method: POST

    Returns:
    A JSON object with a greeting message.
    {
        "msg": "sucess" or error, status code
    }
    """
    try:
        data = request.get_json()
        payload_list = ['Device_Id', 'Device_Details']
        if Validation.validate_data(data, payload_list) is False:
            return {'error_msg': 'invalid payload'}, 400
        api_key = Genericfunc.generate_unique_string()
        secret_key = Genericfunc.generate_unique_string()
        DbUtil.insert_data_into_device_registration(api_key,secret_key,data['Device_Id'], data['Device_Details'])
    except IntegrityError as e:
        print(f"IntegrityError => {e}")
        return {'error_msg':'duplicate entry in devices table'},409
    except Exception as error_obj:
        print(f"error occured = {error_obj}")
        return {'error_msg': error_obj}, 500
    interval = str(Genericfunc.read_data_from_yml('HEART_BEAT_INTERVAL')) + ' sec'
    return {'api_key': api_key, 'secret_key': secret_key, 'heart_beat_interval': interval},201

@device_bp.route('/update_device_info', methods=['PUT'])
@Validation.validate_device
def update_device_info(device_info):
    try:
        data_payload = request.get_json()
        payload_list = ['latitude', 'longitude', 'zone']
        if Validation.validate_data(data_payload, payload_list) is False:
            return {'error_msg': 'invalid payload'}, 400 
        response = DbUtil.update_data_into_device_table(device_info['device_id'], data_payload)
        if response[1] != 201:
            return response
    except Exception as error_obj:
        return f"error occured = {error_obj}"
    return response
    
@device_bp.route('/heartbeat', methods=['PUT'])
@Validation.validate_device
def device_heartbeat(device_info):
    """
    store timestamp register device.

    Endpoint: /device/heartbeat
    Method: PUT

    Returns:
    A JSON object with a greeting message.
    {
        "msg": "sucess" or error, status code
    }
    """
    # api_key = request.headers.get('Api-Key')
    # secret_key = request.headers.get('Secret-Key')
    # if not data_payload or api_key is None or secret_key is None:
    #     return {'error_msg': 'invalid payload'}, 400
    try:
        data_payload = request.get_json()
        payload_list = ['device_status', 'data']
        if Validation.validate_data(data_payload, payload_list) is False:
            return {'error_msg': 'invalid payload'}, 400
        device_status = data_payload['device_status']
        data = data_payload['data']
        keys_list = list(device_status.keys())
        known_key_list = ['status_code', 'status_message']
        if Validation.validate_payload(keys_list, known_key_list) is False:
            return {'error_msg': 'invalid payload'}, 400
        keys_list = list(data.keys())
        known_key_list = ['initializing', 'connected', 'gps_online', 'lidar_online', 'camera_online']
        if Validation.validate_payload(keys_list, known_key_list) is False:
            return {'error_msg': 'invalid payload'}, 400
        status = device_status['status_code']
        response, device_id, time_stamp = DbUtil.insert_data_into_device_info(device_info['device_id'], status)
        if response[1] != 201:
            return response
        DbUtil.insert_data_into_device_status(device_info['device_id'], time_stamp, device_status, data)
    except IntegrityError as e:
        return {'error_msg':'status not in code range'},409
    except Exception as error_obj:
        return f"error occured = {error_obj}"
    return response
    



@device_bp.route('/upload', methods=['POST'])
@Validation.validate_device
def upload_file(device_info):
    """
    upload file.

    Endpoint: /device/upload
    Method: POST

    Returns:
    A JSON object with a greeting message.
    {
        "msg": "sucess" or error, status code
    }
    """
    try:
        start_time = datetime.now()
        if "document" not in request.files:
            return jsonify({"error": "No payload part"}), 400
        file = request.files["document"]
        if file.filename == "":
            return jsonify({"error": "No selected file"}), 400
        formatted_datetime = start_time.strftime('%Y-%m-%d %H:%M:%S')
        file_size = 0
        check_upload = False
        file_size, check_upload = Genericfunc.upload_file_s3(file, device_info['device_id'], formatted_datetime)
        megabytes_size = 0
        if file_size != 0:
            megabytes_size = file_size / (1024.0 ** 2)
        formatted_datetime = start_time.strftime('%Y-%m-%d %H:%M:%S')
        response = DbUtil.insert_data_into_device_metadata(device_info['device_id'], file.filename, megabytes_size, formatted_datetime)
        if response is not None:
            return response
        return jsonify({"message": "File uploaded successfully"}), 200
    except NoCredentialsError:
        return jsonify({"error": "AWS credentials are not available"}), 500
    except Exception as error_obj:
        print(f"error occured = {error_obj.args}")
        if check_upload is True:
            return {'error_msg': 'Something went wrong in DB but file upload successfully'}, 500
        else:
            return {'error_msg': error_obj.args}, 500
    

@device_bp.route('/download', methods=['GET'])  
def download_file():
    """
    download file.

    Endpoint: /device/download
    Method: GET

    Returns:
    A JSON object with a greeting message.
    {
        "msg": "success" or "Error", status code
    }
    """
    #request_data = request.get_json()

    #if not request_data or 'file_name' not in request_data:
        #return jsonify({'error':'File name not part of payload'}), 400
    
    #file_name = request_data['file_name']
    
    #get AWS details from yaml
    try:
        response = Genericfunc.download_file_s3()
    

        return send_file(
            response['Body'],
            as_attachment=True,
            attachment_filename='route.py'
        ), 200 
    except Exception as e:
        print(format_exc())
        return jsonify({"message":f" Requested File not available due to {str(e)}"}), 404