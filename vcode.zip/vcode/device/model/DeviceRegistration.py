

from MyApplication import MyApplication
from marshmallow import fields
from sqlalchemy.dialects.postgresql import BIT


db = MyApplication.get_db()
ma = MyApplication.get_ma()


class DeviceRegistration(db.Model):
    __tablename__ = 'devices'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    actual_id = db.Column(db.Integer)
    api_key = db.Column(db.String)
    secret_key = db.Column(db.String)
    device_details = db.Column(db.String)
    latitude = db.Column(db.Numeric(precision=10, scale=2))
    longitude = db.Column(db.Numeric(precision=10, scale=2))
    zone = db.Column(db.String)

    # __bind_key__ = 'postgres'
    # __tablename__ = 'devices'
    # __table_args__ = {
    #     # 'autoload': True,
    #     'schema': 'public',
    #     # 'autoload_with': db.get_engine(bind='postgres')
    # }




