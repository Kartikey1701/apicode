from MyApplication import MyApplication
from marshmallow import fields
from sqlalchemy.dialects.postgresql import BIT


db = MyApplication.get_db()
ma = MyApplication.get_ma()
class DeviceMetaData(db.Model):
    __tablename__ = 'device_metadata'  # Replace with your actual table name
    device_id = db.Column(db.Integer, primary_key=True)
    file_name = db.Column(db.String)
    file_size = db.Column(db.FLOAT)
    upload_time = db.Column(db.DateTime)