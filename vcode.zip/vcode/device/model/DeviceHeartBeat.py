from MyApplication import MyApplication
from marshmallow import fields
from sqlalchemy.dialects.postgresql import BIT


db = MyApplication.get_db()
ma = MyApplication.get_ma()


class DeviceHeartBeat(db.Model):
    __tablename__ = 'device_heartbeat'  # Replace with your actual table name
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    device_id = db.Column(db.Integer)
    last_beat_time = db.Column(db.DateTime)
    status = db.Column(db.Integer)