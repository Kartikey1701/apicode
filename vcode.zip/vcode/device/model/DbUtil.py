from sqlalchemy import create_engine, select, MetaData, Table, and_, insert
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine, select, MetaData, Table, and_, insert
from datetime import datetime
from device.model.DeviceRegistration import DeviceRegistration
from device.model.DeviceHeartBeat import DeviceHeartBeat
from device.model.LogDeviceHeartBeat import LogDeviceHeartBeat
from device.model.DeviceMetaData import DeviceMetaData
from MyApplication import MyApplication

db = MyApplication.get_db()
class DbUtil():
    """
    A class representing a simple car.

    Attributes:
    - db_user (str): database user.
    - db_password (str): database password.
    - db_host (int): database host.
    - db_name (str): database name.
    - db_url (str): database url for connection.

    Methods:
    - get_url(): return db url for connection.
    - insert_data_into_device_registration(api_key: str, secret_key: str, actual_id: int, device_details: str):
      insert api_key, secret_ket, id, device_detail in device table
    - insert_data_into_device_metadata(api_key, secret_key, file_name, file_size, upload_time):
      check if api_key and secret_key present in device table, insert all file information which upload in device_metadata table
    - insert_data_into_device_info(self, secret_key, api_key):
      check if api_key and secret_key present in device table, insert all file information which upload in device_heartbeat table
    - select_data_device_info(secret_key: str, api_Key: str):
      check api_key and secret_key present in device table.
    """
    @staticmethod
    def insert_data_into_device_registration(api_key, secret_key, actual_id, device_details):
        """
        register the device

        Args:
            api_key (_type_): api_key from payload
            secret_key (_type_): secret_key from payload
            actual_id (_type_): id generated automatically
            device_details (_type_): device datail from payload
        """
        # Create a new recordand insert it into the database
        new_record = DeviceRegistration(api_key=api_key, secret_key=secret_key, actual_id=actual_id, device_details=device_details)
        db.session.add(new_record)
        db.session.commit()
        # Close the session
        db.session.close()
        
    @staticmethod
    def insert_data_into_device_metadata(device_id, file_name, file_size, upload_time):
        """ 
        this method use by API upload
        check if api_key and secret_key register, store file related information in device_matadata table.
        Args:
            api_key (str): api_key from payload
            secret_key (str): secret_key from payload
            file_name (str): file name fetch from file metadat
            file_size (float): calcualte
            upload_time (time): calculate

        Returns:
            list: reponse msg+statuscode
        """
        # Create a new record and insert it into the database
        new_record = DeviceMetaData(device_id=device_id, file_name=file_name, file_size=file_size, upload_time=upload_time)
        db.session.add(new_record)
        db.session.commit()

        # Close the session
        db.session.close()
    
    @staticmethod    
    def insert_data_into_device_info(device_id, status):
        """
        this method used by API heartbeat
        check if device is registered using secret_key and api_key, store time stamp with api and secret key in device_heartbeat
        table
        Args:
            secret_key (str): take from payload
            api_key (str): take from payload

        Returns:
            list: reponse msg+statuscode
        """
        try:
            # Create a new record and insert it into the database
            current_datetime = datetime.utcnow()
            formatted_datetime = current_datetime.strftime('%Y-%m-%d %H:%M:%S')
            if DbUtil.check_device_id(device_id) is False:
                new_record = DeviceHeartBeat(device_id=device_id, last_beat_time=formatted_datetime, status=status)
                db.session.add(new_record)
            else:
                record_to_update = db.session.query(DeviceHeartBeat).filter(DeviceHeartBeat.device_id == device_id).first()  # Example: Update a record with id 1
                if record_to_update:
                    record_to_update.device_id = device_id  # Update the name attribute
                    record_to_update.last_beat_time = formatted_datetime
                else:
                    return 'something wrong in db'
            db.session.commit()
            # Close the session
            db.session.close()
        finally:
            db.session.close()
        mydict = {}
        mydict = {'last_beat_time': formatted_datetime},201
        return mydict, device_id, formatted_datetime
    
    @staticmethod
    def update_data_into_device_table(device_id, data):
        """
        this method used by API heartbeat
        check if device is registered using secret_key and api_key, store time stamp with api and secret key in device_heartbeat
        table
        Args:
            secret_key (str): take from payload
            api_key (str): take from payload

        Returns:
            list: reponse msg+statuscode
        """
        try:
            latitude = data['latitude']
            longitude = data['longitude']
            zone = data['zone']
            record_to_update = db.session.query(DeviceRegistration).filter(DeviceRegistration.id == device_id).first()  # Example: Update a record with id 1
            if record_to_update:
                record_to_update.latitude = latitude  # Update the name attribute
                record_to_update.longitude = longitude
                record_to_update.zone = zone
            else:
                return 'something wrong in db'
            db.session.commit()
            # Close the session
            db.session.close()
        finally:
            db.session.close()
        mydict = {}
        mydict = {'msg': 'data updated successfully for  device-id = {}'.format(device_id)},201
        return mydict
    
    @staticmethod
    def insert_data_into_device_status(device_id, time_stamp, device_status, data):
        """
        this method used by API heartbeat
        check if device is registered using secret_key and api_key, store time stamp with api and secret key in device_heartbeat
        table
        Args:
            secret_key (str): take from payload
            api_key (str): take from payload

        Returns:
            list: reponse msg+statuscode
        """
        try:
            new_record = LogDeviceHeartBeat(device_id=device_id, beat_time=time_stamp, status=device_status['status_code'], status_message=device_status['status_message'], 
                                               initializing=data['initializing'], connected=data['connected'], gps_online=data['gps_online'], lidar_online=data['lidar_online'], 
                                               camera_online=data['camera_online'])
            db.session.add(new_record)
            db.session.commit()
        finally:
            db.session.close()
     
    @staticmethod         
    def select_data_device_info(secret_key, api_Key):
        """
        helping method check device registered or not.
        Args:
            secret_key (str): take from caller method
            api_Key (str): take from caller method

        Returns:
            list: result from devices table according to the filter api_key and secet_key
        """
        try:
            condition = and_(DeviceRegistration.secret_key == secret_key, DeviceRegistration.api_key == api_Key)
            result = db.session.query(DeviceRegistration).filter(condition).all()
            print(result)
            # Close the session
            db.session.close()
        finally:
            db.session.close()
        return result
    
    @staticmethod
    def check_device_id(device_id):
        """
        check device id present or not in heartbeat table
        Args:
            device_id (int): take from payload

        Returns:
            bool: return true if device id exist else return false
        """
        
        condition = DeviceHeartBeat.device_id == device_id
        result = db.session.query(DeviceHeartBeat).filter(condition).all()
        db.session.close()
        is_exist = False
        if len(result) != 0:
            is_exist = True
        return is_exist
