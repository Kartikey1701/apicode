from MyApplication import MyApplication
from marshmallow import fields
from sqlalchemy.dialects.postgresql import BIT


db = MyApplication.get_db()
ma = MyApplication.get_ma()

class LogDeviceHeartBeat(db.Model):
    __tablename__ = 'log_device_heartbeat'  # Replace with your actual table name
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    device_id = db.Column(db.Integer)
    beat_time = db.Column(db.DateTime)
    status = db.Column(db.Integer)
    status_message = db.Column(db.String)
    initializing = db.Column(db.Boolean)
    connected = db.Column(db.Boolean)
    lidar_online = db.Column(db.Boolean)
    gps_online = db.Column(db.Boolean)
    camera_online = db.Column(db.Boolean)
    