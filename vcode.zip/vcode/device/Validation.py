from functools import wraps
from flask import request
import bcrypt
import re
from device.model.DeviceRegistration import DeviceRegistration

class Validation():
    @staticmethod
    def validate_device(func):
        @wraps(func)
        def decorator_function(*args, **kwargs):
            api_key = request.headers.get('Api-Key')
            secret_key = request.headers.get('Secret-Key')
            if api_key is None or secret_key is None:
                return {'error_msg': 'secret or api key missing'}, 400
            result = DeviceRegistration.query.filter(DeviceRegistration.api_key == api_key, DeviceRegistration.secret_key == secret_key).first()
            print(result)
            if(result is None):
                return {'error_msg':'info not exist in db table'},404
            device_id = result.id
            dict_info = {'device_id':device_id}
            return func(dict_info, *args, **kwargs)
        return decorator_function
    
    @staticmethod
    def validate_payload(key_list, known_keys_list):
        return True if key_list == known_keys_list else False

    @staticmethod
    def validate_data(data, known_keys_list):
        if data is None:
            return False
        if all(key in known_keys_list for key in data.keys()):
            return True
        else:
            return False

    @staticmethod
    def password_hashing(password):
        # Hash a password with a randomly-generated salt
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        return hashed_password

    @staticmethod
    def is_valid_email(email):
        # Define a regular expression pattern for a basic email format
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        
        # Use re.match() to check if the email matches the pattern
        match = re.match(pattern, email)
        
        # Return True if there is a match, otherwise, return False
        return match is not None