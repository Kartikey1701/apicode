CREATE TABLE `device_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `device_status` (`id`, `status`)
VALUES
(1, 'Starting'),
(2, 'Online'),
(3, 'Error'),
(4, 'In-Active'),
(5, 'Offline');

CREATE TABLE `devices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `actual_id` int NOT NULL,
  `api_key` varchar(45) NOT NULL,
  `secret_key` varchar(45) NOT NULL,
  `device_details` varchar(45) NOT NULL,
  `latitude` decimal(9,6) DEFAULT NULL,
  `longitude` decimal(9,6) DEFAULT NULL,
  `zone` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `actual_id_UNIQUE` (`actual_id`),
  UNIQUE KEY `api_key_UNIQUE` (`api_key`),
  UNIQUE KEY `secret_key_UNIQUE` (`secret_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `device_heartbeat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `device_id` int NOT NULL,
  `last_beat_time` varchar(45) NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_id_idx` (`device_id`),
  KEY `fk_device_heartbeat_1_idx` (`status`),
  CONSTRAINT `fk_device_heartbeat_1` FOREIGN KEY (`status`) REFERENCES `device_status` (`id`),
  CONSTRAINT `fk_id` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



CREATE TABLE `device_metadata` (
  `device_id` int NOT NULL,
  `file_name` varchar(100) NOT NULL,
  `file_size` float NOT NULL,
  `upload_time` datetime NOT NULL,
  PRIMARY KEY (`device_id`,`upload_time`),
  CONSTRAINT `fk_device_metadata_1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `log_device_heartbeat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `device_id` int NOT NULL,
  `status` int NOT NULL,
  `beat_time` datetime NOT NULL,
  `status_message` varchar(256) NOT NULL,
  `initializing` tinyint(1) NOT NULL,
  `connected` tinyint(1) NOT NULL,
  `gps_online` tinyint(1) NOT NULL,
  `lidar_online` tinyint(1) NOT NULL,
  `camera_online` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_log_device_heartbeat_1_idx` (`status`),
  KEY `fk_log_device_heartbeat_2_idx` (`device_id`),
  CONSTRAINT `fk_log_device_heartbeat_1` FOREIGN KEY (`status`) REFERENCES `device_status` (`id`),
  CONSTRAINT `fk_log_device_heartbeat_2` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `device_user` (
  `username` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `user_id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

